mymixedtypelist = [45, 290578, 1.02, True, "my dog is on the bed.", "45"]
for item in mymixedtypelist:
    print("{} is of the data type {}".format(item,type(item)))