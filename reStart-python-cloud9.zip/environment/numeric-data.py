myValue=1
print(myValue)
print(type(myValue))
print(str(myvalue) + " is of the data type " + str(type(myValue)))